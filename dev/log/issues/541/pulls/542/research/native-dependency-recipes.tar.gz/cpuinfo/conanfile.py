from conan import ConanFile
from conan.errors import ConanInvalidConfiguration
from conan.tools.cmake import CMake, CMakeToolchain, cmake_layout
from conan.tools.files import copy, get, replace_in_file, rmdir
import os

required_conan_version = ">=1.53.0"


class CpuinfoConan(ConanFile):
    package_id_non_embed_mode = "full_mode"
    package_id_unknown_mode = "full_mode"
    name = "cpuinfo"
    description = "cpuinfo is a library to detect essential for performance " \
                  "optimization information about host CPU."
    license = "BSD-2-Clause"
    topics = ("cpu", "cpuid", "cpu-cache", "cpu-model", "instruction-set", "cpu-topology")
    homepage = "https://github.com/pytorch/cpuinfo"
    url = "https://github.com/conan-io/conan-center-index"

    settings = "os", "arch", "compiler", "build_type"
    options = {
        "shared": [True, False],
        "fPIC": [True, False],
        "log_level": ["default", "debug", "info", "warning", "error", "fatal", "none"],
    }
    default_options = {
        "shared": False,
        "fPIC": True,
        "log_level": "default",
    }

    def config_options(self):
        if self.settings.os == "Windows":
            del self.options.fPIC

    def configure(self):
        if self.options.shared:
            self.options.rm_safe("fPIC")
        self.settings.rm_safe("compiler.cppstd")
        self.settings.rm_safe("compiler.libcxx")

    def layout(self):
        cmake_layout(self, src_folder="src")

    def validate(self):
        if self.settings.os == "Windows" and self.options.shared:
            raise ConanInvalidConfiguration("shared cpuinfo not supported on Windows")

    def source(self):
        get(self, **self.conan_data["sources"][self.version], strip_root=True)
        dependency_source_compatibility(self)

    def generate(self):
        tc = CMakeToolchain(self)
        # cpuinfo
        tc.cache_variables["CPUINFO_LIBRARY_TYPE"] = "default"
        tc.cache_variables["CPUINFO_RUNTIME_TYPE"] = "default"
        tc.cache_variables["CPUINFO_LOG_LEVEL"] = self.options.log_level
        tc.variables["CPUINFO_BUILD_TOOLS"] = False
        tc.variables["CPUINFO_BUILD_UNIT_TESTS"] = False
        tc.variables["CPUINFO_BUILD_MOCK_TESTS"] = False
        tc.variables["CPUINFO_BUILD_BENCHMARKS"] = False
        # clog (always static)
        tc.cache_variables["CLOG_RUNTIME_TYPE"] = "default"
        tc.variables["CLOG_BUILD_TESTS"] = False
        tc.variables["CMAKE_POSITION_INDEPENDENT_CODE"] = self.options.get_safe("fPIC", True)
        tc.generate()

    def _patch_sources(self):
        replace_in_file(self, os.path.join(self.source_folder, "CMakeLists.txt"),
                              "SET_PROPERTY(TARGET clog PROPERTY POSITION_INDEPENDENT_CODE ON)",
                              "")

    def build(self):
        self._patch_sources()
        cmake = CMake(self)
        cmake.configure()
        cmake.build()

    def package(self):
        copy(self, "LICENSE", src=self.source_folder, dst=os.path.join(self.package_folder, "licenses"))
        cmake = CMake(self)
        cmake.install()
        rmdir(self, os.path.join(self.package_folder, "lib", "pkgconfig"))

    def package_info(self):
        self.cpp_info.set_property("pkg_config_name", "libcpuinfo")
        self.cpp_info.libs = ["cpuinfo", "clog"]
        if self.settings.os in ["Linux", "FreeBSD"]:
            self.cpp_info.system_libs = ["pthread"]


def dependency_source_compatibility(self):
    from pathlib import Path
    import re

    root = Path(self.source_folder)
    # These dependencies predate CMake's removal of compatibility below 3.10.
    for path in root.rglob("CMakeLists.txt"):
        source = path.read_text()

        def minimum(match):
            version = tuple(int(part) for part in match.group(2).split("."))
            return match.group(1) + ("3.13" if version < (3, 13) else match.group(2))

        path.write_text(
            re.sub(
                r"(cmake_minimum_required\s*\(\s*VERSION\s+)([0-9]+(?:\.[0-9]+)*)",
                minimum,
                source,
                flags=re.IGNORECASE,
            )
        )
    if self.name == "gtest":
        path = root / "googletest/include/gtest/gtest-printers.h"
        source = path.read_text()
        for operator, scale in (("*", "mulfor6"), ("/", "divfor6")):
            old = f"static_cast<int32_t>(val {operator} {scale} + 0.5)"
            if source.count(old) != 1:
                raise ValueError("Review the pinned GTest precision conversion")
            source = source.replace(old, f"static_cast<FloatType>({old})")
        path.write_text(source)
    if self.name == "benchmark":
        path = root / "src/CMakeLists.txt"
        source = path.read_text()
        old = (
            "target_link_libraries(benchmark  ${BENCHMARK_CXX_LIBRARIES} ${CMAKE_THREAD_LIBS_INIT})"
        )
        if source.count(old) != 1:
            raise ValueError("Review the upstream benchmark thread target")
        source = source.replace(
            old, "target_link_libraries(benchmark ${BENCHMARK_CXX_LIBRARIES} Threads::Threads)"
        )
        source, count = re.subn(
            r"if\(NOT CMAKE_THREAD_LIBS_INIT[^\n]+\n.*?\nendif\(\)",
            "",
            source,
            count=1,
            flags=re.DOTALL,
        )
        if count != 1:
            raise ValueError("Review the obsolete benchmark pthread workaround")
        path.write_text(source)
    if self.name == "cpuinfo":
        path = root / "deps/clog/src/clog.c"
        source = path.read_text()
        # Consume short writes, retry EINTR, and stop on a closed/broken sink.
        helper = """
#if !defined(_WIN32) && !defined(__hexagon__)
#include <errno.h>
static void clog_write_all(int fd, const char* bytes, size_t size) {
    while (size != 0) {
        ssize_t count = write(fd, bytes, size);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) break;
        bytes += count;
        size -= (size_t)count;
    }
}
#endif
"""
        source, count = re.subn(r"\bwrite\((STD(?:ERR|OUT)_FILENO),", r"clog_write_all(\1,", source)
        if count != 5:
            raise ValueError("Review the five upstream clog write calls")
        path.write_text(source.replace("#include <clog.h>", "#include <clog.h>\n" + helper))
