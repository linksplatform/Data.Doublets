import os

from conan import ConanFile
from conan.errors import ConanInvalidConfiguration
from conan.tools.build import check_min_cppstd
from conan.tools.files import copy, get
from conan.tools.layout import basic_layout
from conan.tools.microsoft import check_min_vs, is_msvc
from conan.tools.scm import Version

required_conan_version = ">=1.50.0"


class MicrosoftGslConan(ConanFile):
    name = "ms-gsl"
    description = "Microsoft's implementation of the Guidelines Support Library"
    url = "https://github.com/conan-io/conan-center-index"
    homepage = "https://github.com/microsoft/GSL"
    license = "MIT"
    topics = ("gsl", "guidelines", "core", "span")
    no_copy_source = True
    settings = "os", "arch", "compiler", "build_type"
    options = {
        "on_contract_violation": ["terminate", "throw", "unenforced"]
    }
    default_options = {
        "on_contract_violation": "terminate"
    }

    @property
    def _minimum_cpp_standard(self):
        return 14

    @property
    def _contract_map(self):
        return {
            "terminate": "GSL_TERMINATE_ON_CONTRACT_VIOLATION",
            "throw": "GSL_THROW_ON_CONTRACT_VIOLATION",
            "unenforced": "GSL_UNENFORCED_ON_CONTRACT_VIOLATION",
        }

    @property
    def _compilers_minimum_version(self):
        return {
            "gcc": "5",
            "clang": "3.4",
            "apple-clang": "3.4",
        }

    def config_options(self):
        if Version(self.version) >= "3.0.0":
            del self.options.on_contract_violation

    def package_id(self):
        self.info.clear()

    def validate(self):
        if self.settings.compiler.cppstd:
            check_min_cppstd(self, self._minimum_cpp_standard)

        check_min_vs(self, "190")

        if not is_msvc(self):
            minimum_version = self._compilers_minimum_version.get(str(self.settings.compiler), False)
            if minimum_version:
                if Version(self.settings.compiler.version) < minimum_version:
                    raise ConanInvalidConfiguration(
                        f"{self.ref} requires C++{self._minimum_cpp_standard}, which your compiler does not fully support.")
            else:
                self.output.warn(f"{self.ref} requires C++{self._minimum_cpp_standard}. "
                                 "Your compiler is unknown. Assuming it supports C++{self._minimum_cpp_standard}.")

    def layout(self):
        basic_layout(self, src_folder="src")

    def source(self):
        get(self, **self.conan_data["sources"][self.version],
            destination=self.source_folder, strip_root=True)
        dependency_source_compatibility(self)

    def generate(self):
        pass

    def build(self):
        pass

    def package(self):
        copy(self, "LICENSE", self.source_folder, os.path.join(self.package_folder, "licenses"))
        copy(self, "*", os.path.join(self.source_folder, "include"), os.path.join(self.package_folder, "include"))

    def package_info(self):
        self.cpp_info.set_property("cmake_file_name", "Microsoft.GSL")
        self.cpp_info.set_property("cmake_target_name", "Microsoft.GSL::GSL")



        if Version(self.version) < "3.0.0":
            self.cpp_info.components["_ms-gsl"].defines = [
                self._contract_map[str(self.options.on_contract_violation)]
            ]


def dependency_source_compatibility(self):
    from pathlib import Path
    import re

    root = Path(self.source_folder)
    # These dependencies predate CMake's removal of compatibility below 3.10.
    for path in root.rglob("CMakeLists.txt"):
        source = path.read_text()

        def minimum(match):
            version = tuple(int(part) for part in match.group(2).split("."))
            return match.group(1) + ("3.13" if version < (3, 13) else match.group(2))

        path.write_text(
            re.sub(
                r"(cmake_minimum_required\s*\(\s*VERSION\s+)([0-9]+(?:\.[0-9]+)*)",
                minimum,
                source,
                flags=re.IGNORECASE,
            )
        )
    if self.name == "gtest":
        path = root / "googletest/include/gtest/gtest-printers.h"
        source = path.read_text()
        for operator, scale in (("*", "mulfor6"), ("/", "divfor6")):
            old = f"static_cast<int32_t>(val {operator} {scale} + 0.5)"
            if source.count(old) != 1:
                raise ValueError("Review the pinned GTest precision conversion")
            source = source.replace(old, f"static_cast<FloatType>({old})")
        path.write_text(source)
    if self.name == "benchmark":
        path = root / "src/CMakeLists.txt"
        source = path.read_text()
        old = (
            "target_link_libraries(benchmark  ${BENCHMARK_CXX_LIBRARIES} ${CMAKE_THREAD_LIBS_INIT})"
        )
        if source.count(old) != 1:
            raise ValueError("Review the upstream benchmark thread target")
        source = source.replace(
            old, "target_link_libraries(benchmark ${BENCHMARK_CXX_LIBRARIES} Threads::Threads)"
        )
        source, count = re.subn(
            r"if\(NOT CMAKE_THREAD_LIBS_INIT[^\n]+\n.*?\nendif\(\)",
            "",
            source,
            count=1,
            flags=re.DOTALL,
        )
        if count != 1:
            raise ValueError("Review the obsolete benchmark pthread workaround")
        path.write_text(source)
    if self.name == "cpuinfo":
        path = root / "deps/clog/src/clog.c"
        source = path.read_text()
        # Consume short writes, retry EINTR, and stop on a closed/broken sink.
        helper = """
#if !defined(_WIN32) && !defined(__hexagon__)
#include <errno.h>
static void clog_write_all(int fd, const char* bytes, size_t size) {
    while (size != 0) {
        ssize_t count = write(fd, bytes, size);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) break;
        bytes += count;
        size -= (size_t)count;
    }
}
#endif
"""
        source, count = re.subn(r"\bwrite\((STD(?:ERR|OUT)_FILENO),", r"clog_write_all(\1,", source)
        if count != 5:
            raise ValueError("Review the five upstream clog write calls")
        path.write_text(source.replace("#include <clog.h>", "#include <clog.h>\n" + helper))
