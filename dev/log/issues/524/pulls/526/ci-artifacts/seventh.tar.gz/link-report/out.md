# Summary

| Status         | Count |
|----------------|-------|
| 🔍 Total       | 68    |
| ✅ Successful  | 55    |
| ⏳ Timeouts    | 0     |
| 🔀 Redirected  | 5     |
| 👻 Excluded    | 8     |
| ❓ Unknown     | 0     |
| 🚫 Errors      | 0     |
| ⛔ Unsupported | 0     |

## Redirects per input

### Redirects in README.md

* [200] <https://discord.gg/eEXJyjWv5e> | Redirect: Followed 1 redirect resolving to the final status of: OK. Redirects: https://discord.gg/eEXJyjWv5e --[301]--> https://discord.com/invite/eEXJyjWv5e

### Redirects in README.ru.md

* [200] <https://github.com/linksplatform/Examples.Doublets.CRUD.DotNet> | Redirect: Followed 1 redirect resolving to the final status of: OK. Redirects: https://github.com/linksplatform/Examples.Doublets.CRUD.DotNet --[301]--> https://github.com/linksplatform/Examples.Doublets.CRUD
* [200] <https://linksplatform.github.io/Data.Doublets> | Redirect: Followed 1 redirect resolving to the final status of: OK. Redirects: https://linksplatform.github.io/Data.Doublets --[301]--> https://linksplatform.github.io/Data.Doublets/
* [200] <https://raw.github.com/linksplatform/Documentation/master/doc/Dependencies/Platform.Data.Doublets.cpp.svg?sanitize=true> | Redirect: Followed 1 redirect resolving to the final status of: OK. Redirects: https://raw.github.com/linksplatform/Documentation/master/doc/Dependencies/Platform.Data.Doublets.cpp.svg?sanitize=true --[301]--> https://raw.githubusercontent.com/linksplatform/Documentation/master/doc/Dependencies/Platform.Data.Doublets.cpp.svg?sanitize=true
* [200] <https://raw.github.com/linksplatform/Documentation/master/doc/Dependencies/Platform.Data.Doublets.svg?sanitize=true> | Redirect: Followed 1 redirect resolving to the final status of: OK. Redirects: https://raw.github.com/linksplatform/Documentation/master/doc/Dependencies/Platform.Data.Doublets.svg?sanitize=true --[301]--> https://raw.githubusercontent.com/linksplatform/Documentation/master/doc/Dependencies/Platform.Data.Doublets.svg?sanitize=true

[Full Github Actions output](https://github.com/linksplatform/Data.Doublets/actions/runs/40842727244?check_suite_focus=true)
